<?php

declare(strict_types=1);

defined('ABSPATH') || exit;
use Polski\Admin\AdminNotes;
use Polski\Admin\CSVImportExport;
use Polski\Admin\ModulesPage;
use Polski\Admin\PostTypes;
use Polski\Admin\ProductMetaBox;
use Polski\Compatibility\ElementorCompat;
use Polski\Hook\AdminHooks;
use Polski\Hook\ProductHooks;
use Polski\Hook\CartHooks;
use Polski\Hook\CheckoutHooks;
use Polski\Hook\OrderHooks;
use Polski\Hook\LoopHooks;
use Polski\Integration\IntegrationManager;
use Polski\Rest\CheckboxController;
use Polski\Rest\LegalPageController;
use Polski\Rest\SearchController;
use Polski\Rest\SettingsController;
use Polski\Rest\WithdrawalController;
use Polski\Service\WithdrawalService;
use Polski\Service\CheckboxService;
use Polski\Service\DoubleOptInService;
use Polski\Service\EmailService;
use Polski\Service\FilterService;
use Polski\Service\OmnibusService;
use Polski\Service\SearchService;
use Polski\Service\CompareService;
use Polski\Service\QuickViewService;
use Polski\Service\BadgeService;
use Polski\Service\TabManagerService;
use Polski\Service\FeaturedVideoService;
use Polski\Service\GalleryZoomService;
use Polski\Service\ProductSliderService;
use Polski\Service\WaitlistService;
use Polski\Service\InfiniteScrollService;
use Polski\Service\PopupService;
use Polski\Service\WishlistService;
use Polski\Service\DisputeResolutionService;
use Polski\Shortcode\ShortcodeManager;

/**
 * Hook subscriber classes to boot and register.
 *
 * Order matters: services are booted and hooks registered in this order.
 *
 * @return list<class-string<\Polski\Contract\HasHooks>>
 */
return [
    // Administration and Core Infrastructure.
    AdminHooks::class,
    ModulesPage::class,
    PostTypes::class,
    ProductMetaBox::class,
    AdminNotes::class,
    CSVImportExport::class,
    \Polski\Admin\DeactivationHandler::class,

    // Core services.
    CheckboxService::class,
    OmnibusService::class,
    FilterService::class,
    DoubleOptInService::class,
    EmailService::class,
    DisputeResolutionService::class,
    SearchService::class,
    WishlistService::class,
    CompareService::class,
    QuickViewService::class,
    BadgeService::class,
    TabManagerService::class,
    FeaturedVideoService::class,
    GalleryZoomService::class,
    ProductSliderService::class,
    WaitlistService::class,
    InfiniteScrollService::class,
    PopupService::class,

    // New compliance & feature modules.
    \Polski\Service\GPSRService::class,
    \Polski\Service\VerifiedReviewService::class,
    \Polski\Service\DSAService::class,
    \Polski\Service\KSeFReadyService::class,
    \Polski\Service\SecurityIncidentService::class,
    \Polski\Service\SiteAuditService::class,
    \Polski\Service\CRAReadinessService::class,
    \Polski\Service\DPATrackerService::class,
    \Polski\Service\NipLookupService::class,
    ProductHooks::class,
    LoopHooks::class,
    CartHooks::class,
    CheckoutHooks::class,
    OrderHooks::class,

    // Withdrawal service (needs hooks for My Account).
    WithdrawalService::class,

    // Shortcodes.
    ShortcodeManager::class,

    // REST API.
    SettingsController::class,
    CheckboxController::class,
    WithdrawalController::class,
    LegalPageController::class,
    SearchController::class,
];
