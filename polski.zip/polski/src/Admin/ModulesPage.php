<?php

declare(strict_types=1);
namespace Polski\Admin;

defined('ABSPATH') || exit;

use Polski\Contract\HasHooks;

/**
 * Module management page - toggleable feature groups.
 *
 * Each module corresponds to a feature set that can be enabled/disabled.
 * Modules are stored as a serialized array in polski_modules option.
 */
final class ModulesPage implements HasHooks
{
    private const OPTION = 'polski_modules';

    public function registerHooks(): void
    {
        add_action('admin_post_polski_save_modules', [$this, 'handleSave']);
    }

    /**
     * Get all module definitions with their current state.
     *
     * @return list<array{id: string, name: string, description: string, group: string, enabled: bool, icon: string, links: list<array{label: string, url: string}>}>
     */
    public function getModules(): array
    {
        $saved = get_option(self::OPTION, []);
        $saved = is_array($saved) ? $saved : [];

        $modules = [
            // === Prices and Display ===
            [
                'id' => 'unit_price',
                'name' => __('Unit price', 'polski'),
                'description' => __('Display price per unit (e.g. per 1 kg, per 100 ml) according to Polish consumer law.', 'polski'),
                'group' => __('Prices and Display', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-tag',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_prices|unit_price_text', 'label' => __('Display format', 'polski'), 'type' => 'text', 'default' => '{price} / {unit}', 'hint' => __('Variables: {price}, {unit}', 'polski')],
                    ['key' => 'polski_prices|unit_price_show_loop', 'label' => __('Show on product lists', 'polski'), 'type' => 'checkbox', 'default' => true],
                ],
            ],
            [
                'id' => 'omnibus',
                'name' => __('Lowest price (Omnibus)', 'polski'),
                'description' => __('Track price history and display the lowest price from the last 30 days for products on sale. Required by the Omnibus Directive (EU 2019/2161).', 'polski'),
                'group' => __('Prices and Display', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-chart-line',
                'links' => [],
                'settings' => [
                    ['key' => '_omnibus_header_1', 'label' => '', 'type' => 'html', 'html' => '<strong style="font-size:13px;">' . __('Price tracking', 'polski') . '</strong>'],
                    ['key' => 'polski_omnibus|days', 'label' => __('Tracking period (days)', 'polski'), 'type' => 'number', 'default' => 30, 'hint' => __('Directive requires a minimum of 30 days', 'polski')],
                    ['key' => 'polski_omnibus|prune_after_days', 'label' => __('Keep history (days)', 'polski'), 'type' => 'number', 'default' => 90, 'hint' => __('Older data will be automatically deleted', 'polski')],
                    ['key' => 'polski_omnibus|include_tax', 'label' => __('Prices with tax', 'polski'), 'type' => 'checkbox', 'default' => true, 'hint' => __('Track and display gross prices', 'polski')],

                    ['key' => '_omnibus_header_2', 'label' => '', 'type' => 'html', 'html' => '<strong style="font-size:13px;margin-top:8px;display:block;">' . __('Display', 'polski') . '</strong>'],
                    ['key' => 'polski_omnibus|display_on_sale_only', 'label' => __('Only products on sale', 'polski'), 'type' => 'checkbox', 'default' => true, 'hint' => __('Show info only when the product has a sale price', 'polski')],
                    ['key' => 'polski_omnibus|show_on_single', 'label' => __('Product page', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_omnibus|show_on_loop', 'label' => __('Product lists (shop, categories)', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_omnibus|show_on_related', 'label' => __('Related and featured products', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_omnibus|show_on_cart', 'label' => __('Cart', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_omnibus|show_regular_price', 'label' => __('Show regular price (before sale)', 'polski'), 'type' => 'checkbox', 'default' => false, 'hint' => __('Display additional information about the price before the sale started', 'polski')],

                    ['key' => '_omnibus_header_3', 'label' => '', 'type' => 'html', 'html' => '<strong style="font-size:13px;margin-top:8px;display:block;">' . __('Message template', 'polski') . '</strong>'],
                    ['key' => 'polski_omnibus|display_text', 'label' => __('Message content', 'polski'), 'type' => 'text', 'default' => 'Lowest price in the last {days} days: {price}', 'hint' => __('Variables: {price}, {days}, {date}, {regular_price}', 'polski')],
                    ['key' => 'polski_omnibus|no_history_text', 'label' => __('No price history', 'polski'), 'type' => 'select', 'default' => 'hide', 'options' => ['hide' => __('Hide message', 'polski'), 'current' => __('Show current price', 'polski'), 'custom' => __('Custom text', 'polski')]],
                    ['key' => 'polski_omnibus|no_history_custom_text', 'label' => __('Custom text (no history)', 'polski'), 'type' => 'text', 'default' => 'Price has not changed in {days} days'],
                    ['key' => 'polski_omnibus|price_count_from', 'label' => __('Calculated from', 'polski'), 'type' => 'select', 'default' => 'sale_start', 'options' => ['sale_start' => __('Sale start date', 'polski'), 'today' => __('Today', 'polski')], 'hint' => __('Reference point for calculating the lowest price', 'polski')],

                    ['key' => '_omnibus_header_4', 'label' => '', 'type' => 'html', 'html' => '<strong style="font-size:13px;margin-top:8px;display:block;">' . __('Variable products', 'polski') . '</strong>'],
                    ['key' => 'polski_omnibus|variable_tracking', 'label' => __('Track variations separately', 'polski'), 'type' => 'checkbox', 'default' => true, 'hint' => __('Each variation has its own price history', 'polski')],
                ],
            ],
            [
                'id' => 'tax_display',
                'name' => __('VAT Display', 'polski'),
                'description' => __('Configuration for gross/net prices display, VAT rate info, and small business exemption support (Art. 113 of the VAT Act).', 'polski'),
                'group' => __('Prices and Display', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-money-alt',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_taxes|tax_display_mode', 'label' => __('Price display mode', 'polski'), 'type' => 'select', 'default' => 'brutto', 'options' => ['brutto' => __('Gross (including VAT)', 'polski'), 'netto' => __('Net (excluding VAT)', 'polski')]],
                    ['key' => 'polski_taxes|vat_notice_text', 'label' => __('VAT notice text', 'polski'), 'type' => 'text', 'default' => 'including {rate}% VAT', 'hint' => __('Variables: {rate}', 'polski')],
                    ['key' => 'polski_general|small_business', 'label' => __('Small business exemption (Art. 113)', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_taxes|vat_exempt_notice', 'label' => __('Exemption text', 'polski'), 'type' => 'text', 'default' => 'Exempt from VAT based on Art. 113 par. 1 of the VAT Act'],
                ],
            ],
            [
                'id' => 'delivery_time',
                'name' => __('Delivery time', 'polski'),
                'description' => __('Display estimated delivery time on the product page. Configuration per product or variation with default fallback.', 'polski'),
                'group' => __('Prices and Display', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-clock',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_delivery|display_format', 'label' => __('Display format', 'polski'), 'type' => 'text', 'default' => 'Delivery time: {time}', 'hint' => __('Variables: {time}', 'polski')],
                    ['key' => 'polski_delivery|default_delivery_time', 'label' => __('Default delivery time', 'polski'), 'type' => 'delivery_time_select'],
                ],
            ],
            [
                'id' => 'shipping_notice',
                'name' => __('Shipping costs info', 'polski'),
                'description' => __('Link to a shipping costs page displayed next to the product price.', 'polski'),
                'group' => __('Prices and Display', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-car',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_prices|shipping_costs_text', 'label' => __('Link text', 'polski'), 'type' => 'text', 'default' => 'plus shipping costs'],
                ],
            ],

            // === Checkout and Orders ===
            [
                'id' => 'checkout_button',
                'name' => __('Checkout button', 'polski'),
                'description' => __('Change order button text to "Order with obligation to pay" according to Polish law.', 'polski'),
                'group' => __('Checkout and Orders', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-cart',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_checkout|order_button_text', 'label' => __('Button text', 'polski'), 'type' => 'text', 'default' => 'Order with obligation to pay'],
                ],
            ],
            [
                'id' => 'legal_checkboxes',
                'name' => __('Legal checkboxes', 'polski'),
                'description' => __('7 built-in checkboxes: terms and conditions, privacy policy, right of withdrawal, digital content, delivery notifications, review reminder, marketing.', 'polski'),
                'group' => __('Checkout and Orders', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-yes-alt',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_checkout|terms_checkbox_enabled', 'label' => __('Terms and Conditions', 'polski'), 'type' => 'checkbox', 'default' => true],
                    /* translators: %s: terms page URL placeholder */
                    ['key' => 'polski_checkout|terms_checkbox_label', 'label' => __('Label - Terms', 'polski'), 'type' => 'textarea', 'default' => 'I have read and accept the <a href="%s" target="_blank">Terms and Conditions</a>.', 'hint' => __('Use %s as a placeholder for the terms page link', 'polski')],
                    ['key' => 'polski_checkout|terms_checkbox_error', 'label' => __('Error - Terms', 'polski'), 'type' => 'text', 'default' => 'You must accept the Terms and Conditions to place an order.'],
                    ['key' => 'polski_checkout|terms_checkbox_description', 'label' => __('Description - Terms', 'polski'), 'type' => 'text', 'default' => 'Acceptance of the Terms and Conditions.'],
                    ['key' => 'polski_checkout|privacy_checkbox_enabled', 'label' => __('Privacy Policy', 'polski'), 'type' => 'checkbox', 'default' => true],
                    /* translators: %s: privacy policy URL placeholder */
                    ['key' => 'polski_checkout|privacy_checkbox_label', 'label' => __('Label - Privacy Policy', 'polski'), 'type' => 'textarea', 'default' => 'I have read and accept the <a href="%s" target="_blank">Privacy Policy</a>.', 'hint' => __('Use %s as a placeholder for the privacy policy link', 'polski')],
                    ['key' => 'polski_checkout|privacy_checkbox_error', 'label' => __('Error - Privacy Policy', 'polski'), 'type' => 'text', 'default' => 'You must accept the Privacy Policy.'],
                    ['key' => 'polski_checkout|privacy_checkbox_description', 'label' => __('Description - Privacy Policy', 'polski'), 'type' => 'text', 'default' => 'Acceptance of the Privacy Policy.'],
                    ['key' => 'polski_checkout|withdrawal_checkbox_enabled', 'label' => __('Right of withdrawal', 'polski'), 'type' => 'checkbox', 'default' => true],
                    /* translators: %s: withdrawal information URL placeholder */
                    ['key' => 'polski_checkout|withdrawal_checkbox_label', 'label' => __('Label - Right of withdrawal', 'polski'), 'type' => 'textarea', 'default' => 'I confirm that I have been informed about the <a href="%s" target="_blank">right of withdrawal</a> within 14 days.', 'hint' => __('Use %s as a placeholder for the returns or withdrawal page link', 'polski')],
                    ['key' => 'polski_checkout|withdrawal_checkbox_error', 'label' => __('Error - Right of withdrawal', 'polski'), 'type' => 'text', 'default' => 'You must confirm that you have read the information about the right of withdrawal.'],
                    ['key' => 'polski_checkout|withdrawal_checkbox_description', 'label' => __('Description - Right of withdrawal', 'polski'), 'type' => 'text', 'default' => 'Confirmation of information about the 14-day right of withdrawal.'],
                    ['key' => 'polski_checkout|digital_waiver_checkbox_enabled', 'label' => __('Digital content (waiver)', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_checkout|digital_waiver_checkbox_label', 'label' => __('Label - Digital content', 'polski'), 'type' => 'textarea', 'default' => 'I agree to start the delivery of digital content before the expiry of the withdrawal period and I acknowledge the loss of the right of withdrawal.'],
                    ['key' => 'polski_checkout|digital_waiver_checkbox_error', 'label' => __('Error - Digital content', 'polski'), 'type' => 'text', 'default' => 'You must agree to the immediate delivery of digital content.'],
                    ['key' => 'polski_checkout|digital_waiver_checkbox_description', 'label' => __('Description - Digital content', 'polski'), 'type' => 'text', 'default' => 'Waiver of the right of withdrawal for digital content.'],
                    ['key' => 'polski_checkout|parcel_delivery_checkbox_enabled', 'label' => __('Delivery notifications', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_checkout|parcel_delivery_checkbox_label', 'label' => __('Label - Delivery notifications', 'polski'), 'type' => 'textarea', 'default' => 'I agree to receive SMS/email notifications about the delivery status of the shipment.'],
                    ['key' => 'polski_checkout|parcel_delivery_checkbox_description', 'label' => __('Description - Delivery notifications', 'polski'), 'type' => 'text', 'default' => 'Optional consent for delivery notifications.'],
                    ['key' => 'polski_checkout|review_reminder_checkbox_enabled', 'label' => __('Review reminder', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_checkout|review_reminder_checkbox_label', 'label' => __('Label - Review reminder', 'polski'), 'type' => 'textarea', 'default' => 'I agree to receive a reminder to leave a review via email after the purchase.'],
                    ['key' => 'polski_checkout|review_reminder_checkbox_description', 'label' => __('Description - Review reminder', 'polski'), 'type' => 'text', 'default' => 'Optional consent for review reminders.'],
                    ['key' => 'polski_checkout|marketing_checkbox_enabled', 'label' => __('Marketing consent', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_checkout|marketing_checkbox_label', 'label' => __('Label - Marketing', 'polski'), 'type' => 'textarea', 'default' => 'I agree to receive marketing communication and newsletter.'],
                    ['key' => 'polski_checkout|marketing_checkbox_description', 'label' => __('Description - Marketing', 'polski'), 'type' => 'text', 'default' => 'Optional marketing consent.'],
                ],
            ],
            [
                'id' => 'nip_lookup',
                'name' => __('NIP - Verification and Autocomplete', 'polski'),
                'description' => __('NIP field on the checkout page with checksum validation. Automatic retrieval of company data from the GUS REGON database after entering NIP.', 'polski'),
                'group' => __('Checkout and Orders', 'polski'),
                'enabled' => false,
                'pro' => false,
                'icon' => 'dashicons-building',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_nip|nip_required', 'label' => __('NIP required on checkout', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_nip|gus_environment', 'label' => __('GUS API environment', 'polski'), 'type' => 'select', 'default' => 'test', 'options' => ['test' => __('Testing', 'polski'), 'production' => __('Production', 'polski')]],
                    ['key' => 'polski_nip|gus_api_key', 'label' => __('GUS API Key (production)', 'polski'), 'type' => 'text', 'default' => '', 'hint' => __('Request a key on the stat.gov.pl website. In test mode, a test key will be used.', 'polski')],
                ],
            ],
            [
                'id' => 'consent_logging',
                'name' => __('Consent Logging (GDPR)', 'polski'),
                'description' => __('Recording all consents given by customers with IP address, user agent, and timestamp. GDPR compliant.', 'polski'),
                'group' => __('Checkout and Orders', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-shield',
                'links' => [],
                'settings' => [],
            ],
            // === Consumer Rights ===
            [
                'id' => 'legal_pages',
                'name' => __('Legal Pages', 'polski'),
                'description' => __('Automatic generation of pages: Terms and Conditions, Privacy Policy, Right of Withdrawal, Complaints.', 'polski'),
                'group' => __('Consumer Rights', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-media-document',
                'links' => [],
                'settings' => [
                    ['key' => '_legal_pages_link', 'label' => '', 'type' => 'html', 'html' => '<a href="' . admin_url('admin.php?page=polski&tab=dashboard') . '">' . __('Manage legal pages on Dashboard &rarr;', 'polski') . '</a>'],
                ],
            ],
            [
                'id' => 'withdrawal',
                'name' => __('Right of withdrawal (14 days)', 'polski'),
                'description' => __('Withdrawal request form, My Account action with confirmation step, confirmation email, and per-product exclusions.', 'polski'),
                'group' => __('Consumer Rights', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-undo',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_withdrawal|button_text', 'label' => __('Order action label', 'polski'), 'type' => 'text', 'default' => __('Withdraw from contract', 'polski')],
                    ['key' => 'polski_withdrawal|form_title', 'label' => __('Form title', 'polski'), 'type' => 'text', 'default' => __('Withdrawal request', 'polski')],
                    ['key' => 'polski_withdrawal|form_intro_text', 'label' => __('Form introduction', 'polski'), 'type' => 'textarea', 'default' => __('You are submitting a withdrawal request for order #{order_number} placed on {order_date}.', 'polski'), 'hint' => __('Variables: {order_number}, {order_date}', 'polski')],
                    ['key' => 'polski_withdrawal|legal_notice_text', 'label' => __('Legal notice', 'polski'), 'type' => 'textarea', 'default' => __('Under Polish consumer law, you may withdraw from the contract within 14 days without giving a reason.', 'polski')],
                    ['key' => 'polski_withdrawal|items_heading', 'label' => __('Order items heading', 'polski'), 'type' => 'text', 'default' => __('Order items', 'polski')],
                    ['key' => 'polski_withdrawal|column_product', 'label' => __('Product column', 'polski'), 'type' => 'text', 'default' => __('Product', 'polski')],
                    ['key' => 'polski_withdrawal|column_quantity', 'label' => __('Quantity column', 'polski'), 'type' => 'text', 'default' => __('Quantity', 'polski')],
                    ['key' => 'polski_withdrawal|column_price', 'label' => __('Price column', 'polski'), 'type' => 'text', 'default' => __('Price', 'polski')],
                    ['key' => 'polski_withdrawal|exempt_notice_text', 'label' => __('Exemption notice', 'polski'), 'type' => 'text', 'default' => __('(This product is excluded from the right of withdrawal)', 'polski')],
                    ['key' => 'polski_withdrawal|reason_label', 'label' => __('Reason field label', 'polski'), 'type' => 'text', 'default' => __('Reason for withdrawal (optional)', 'polski')],
                    ['key' => 'polski_withdrawal|submit_button_text', 'label' => __('Submit button text', 'polski'), 'type' => 'text', 'default' => __('Submit withdrawal request', 'polski')],
                    ['key' => 'polski_withdrawal|invalid_nonce_text', 'label' => __('Invalid nonce message', 'polski'), 'type' => 'text', 'default' => __('Something went wrong on our side. Please try again.', 'polski')],
                    ['key' => 'polski_withdrawal|order_not_found_text', 'label' => __('Order not found message', 'polski'), 'type' => 'text', 'default' => __('We could not find that order.', 'polski')],
                    ['key' => 'polski_withdrawal|permission_error_text', 'label' => __('Permission error message', 'polski'), 'type' => 'text', 'default' => __('You do not have permission to withdraw from this order.', 'polski')],
                    ['key' => 'polski_withdrawal|success_text', 'label' => __('Success message', 'polski'), 'type' => 'text', 'default' => __('Your withdrawal request has been received. We will send a confirmation email shortly.', 'polski')],
                    ['key' => 'polski_withdrawal|not_eligible_text', 'label' => __('Not eligible message', 'polski'), 'type' => 'text', 'default' => __('This order is not eligible for withdrawal.', 'polski')],
                    ['key' => 'polski_withdrawal|status_heading', 'label' => __('Status section heading', 'polski'), 'type' => 'text', 'default' => __('Withdrawal request', 'polski')],
                    ['key' => 'polski_withdrawal|status_label', 'label' => __('Status label', 'polski'), 'type' => 'text', 'default' => __('Status', 'polski')],
                    ['key' => 'polski_withdrawal|submitted_label', 'label' => __('Submitted label', 'polski'), 'type' => 'text', 'default' => __('Submitted', 'polski')],
                    ['key' => 'polski_withdrawal|requested_order_note', 'label' => __('Order note after request', 'polski'), 'type' => 'text', 'default' => __('The customer submitted a withdrawal request.', 'polski')],
                    ['key' => 'polski_withdrawal|confirmed_order_note', 'label' => __('Order note after confirmation', 'polski'), 'type' => 'text', 'default' => __('The withdrawal request has been confirmed.', 'polski')],
                    ['key' => 'polski_withdrawal|status_date_format', 'label' => __('Status date format', 'polski'), 'type' => 'text', 'default' => __('Y-m-d H:i', 'polski')],
                    ['key' => 'polski_withdrawal|email_subject', 'label' => __('Confirmation email subject', 'polski'), 'type' => 'text', 'default' => __('Your withdrawal request for order #{order_number} has been confirmed.', 'polski'), 'hint' => __('Variables: {order_number}, {order_date}, {withdrawal_date}', 'polski')],
                    ['key' => 'polski_withdrawal|email_heading', 'label' => __('Confirmation email heading', 'polski'), 'type' => 'text', 'default' => __('Withdrawal confirmed', 'polski')],
                    ['key' => 'polski_withdrawal|email_greeting', 'label' => __('Email greeting', 'polski'), 'type' => 'text', 'default' => __('Hello {name},', 'polski'), 'hint' => __('Variable: {name}', 'polski')],
                    ['key' => 'polski_withdrawal|email_intro_text', 'label' => __('Confirmation email body', 'polski'), 'type' => 'textarea', 'default' => __('Your withdrawal request for order #{order_number} has been confirmed.', 'polski'), 'hint' => __('Variable: {order_number}', 'polski')],
                    ['key' => 'polski_withdrawal|email_reason_label', 'label' => __('Reason label in email', 'polski'), 'type' => 'text', 'default' => __('Your reason', 'polski')],
                    ['key' => 'polski_withdrawal|email_return_instruction', 'label' => __('Return instruction in email', 'polski'), 'type' => 'textarea', 'default' => __('Please return the products to the address below within 14 days:', 'polski')],
                    ['key' => 'polski_withdrawal|email_additional_content', 'label' => __('Additional email content', 'polski'), 'type' => 'textarea', 'default' => __('Your refund will be processed within 14 days after the returned products are received.', 'polski')],
                ],
            ],
            [
                'id' => 'dispute_resolution',
                'name' => __('Dispute Resolution (ODR)', 'polski'),
                'description' => __('Displaying information about the European Commission\'s Online Dispute Resolution (ODR) platform.', 'polski'),
                'group' => __('Consumer Rights', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-admin-site-alt3',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_general|dispute_resolution_text', 'label' => __('ODR info content', 'polski'), 'type' => 'textarea', 'default' => 'ODR Platform: https://ec.europa.eu/consumers/odr'],
                    ['key' => 'polski_general|admin_pages_generated_notice', 'label' => __('Message after generating legal pages', 'polski'), 'type' => 'textarea', 'default' => 'Ready! We have generated initial drafts of legal pages for you. Review them, adjust to your needs, and feel free to publish.'],
                    ['key' => 'polski_general|admin_modules_saved_notice', 'label' => __('Message after saving modules', 'polski'), 'type' => 'text', 'default' => 'Modules saved.'],
                    ['key' => 'polski_general|admin_setup_note_title', 'label' => __('Onboarding note title', 'polski'), 'type' => 'text', 'default' => 'Configure Polski for your store'],
                    ['key' => 'polski_general|admin_setup_note_content', 'label' => __('Onboarding note content', 'polski'), 'type' => 'textarea', 'default' => 'Just a moment and the store will be ready. Review the modules, set up legal pages, and finish the configuration in the Polski panel.'],
                    ['key' => 'polski_general|admin_setup_note_button', 'label' => __('Onboarding note button', 'polski'), 'type' => 'text', 'default' => 'Open Polski configuration'],
                    ['key' => 'polski_general|admin_status_active', 'label' => __('Active status', 'polski'), 'type' => 'text', 'default' => 'Active'],
                    ['key' => 'polski_general|admin_status_inactive', 'label' => __('Inactive status', 'polski'), 'type' => 'text', 'default' => 'Disabled'],
                    ['key' => 'polski_general|admin_status_unconfigured', 'label' => __('Unconfigured status', 'polski'), 'type' => 'text', 'default' => 'Unconfigured'],
                    ['key' => 'polski_general|admin_legal_pages_card_title', 'label' => __('Legal pages card title', 'polski'), 'type' => 'text', 'default' => 'Legal pages'],
                    ['key' => 'polski_general|admin_legal_pages_card_progress', 'label' => __('Legal pages configuration progress', 'polski'), 'type' => 'text', 'default' => 'You already have {done} out of {total} steps behind you. Excellent!', 'hint' => __('Variables: {done}, {total}', 'polski')],
                    ['key' => 'polski_general|admin_vat_card_title', 'label' => __('VAT card title', 'polski'), 'type' => 'text', 'default' => 'Tax display'],
                    ['key' => 'polski_general|admin_vat_small_business_text', 'label' => __('Small business exemption text', 'polski'), 'type' => 'text', 'default' => 'Small business exemption (Art. 113)'],
                    ['key' => 'polski_general|admin_vat_standard_text', 'label' => __('Standard VAT text', 'polski'), 'type' => 'text', 'default' => 'Standard VAT'],
                    ['key' => 'polski_general|admin_doi_card_title', 'label' => __('DOI card title', 'polski'), 'type' => 'text', 'default' => 'Double Opt-In (DOI)'],
                    ['key' => 'polski_general|admin_legal_pages_section_title', 'label' => __('Legal pages section title', 'polski'), 'type' => 'text', 'default' => 'Legal pages'],
                    ['key' => 'polski_general|admin_legal_pages_table_page', 'label' => __('Page column header', 'polski'), 'type' => 'text', 'default' => 'Page'],
                    ['key' => 'polski_general|admin_legal_pages_table_status', 'label' => __('Status column header', 'polski'), 'type' => 'text', 'default' => 'Status'],
                    ['key' => 'polski_general|admin_legal_pages_published', 'label' => __('Published status', 'polski'), 'type' => 'text', 'default' => 'Published'],
                    ['key' => 'polski_general|admin_legal_pages_draft', 'label' => __('Draft status', 'polski'), 'type' => 'text', 'default' => 'Draft'],
                    ['key' => 'polski_general|admin_legal_pages_missing', 'label' => __('Missing status', 'polski'), 'type' => 'text', 'default' => 'Not created'],
                    ['key' => 'polski_general|admin_edit_button_text', 'label' => __('Edit button text', 'polski'), 'type' => 'text', 'default' => 'Edit'],
                    ['key' => 'polski_general|admin_generate_pages_empty_text', 'label' => __('Legal pages empty state', 'polski'), 'type' => 'text', 'default' => 'No legal pages have been created yet. Generate them to get started.'],
                    ['key' => 'polski_general|admin_generate_pages_button_text', 'label' => __('Generate pages button text', 'polski'), 'type' => 'text', 'default' => 'Generate legal pages'],
                    ['key' => 'polski_general|admin_next_steps_title', 'label' => __('Next steps title', 'polski'), 'type' => 'text', 'default' => 'Next steps'],
                    ['key' => 'polski_general|admin_next_steps_publish_pages', 'label' => __('Step - publish pages', 'polski'), 'type' => 'text', 'default' => 'Publish your legal pages: Terms and Conditions, Privacy Policy, Right of Withdrawal and Complaints.'],
                    ['key' => 'polski_general|admin_next_steps_tax', 'label' => __('Step - VAT rates', 'polski'), 'type' => 'textarea', 'default' => 'Configure <a href="%s">VAT rates</a> in WooCommerce for the Polish market: 23%%, 8%%, 5%% and 0%%.'],
                    ['key' => 'polski_general|admin_next_steps_shipping', 'label' => __('Step - shipping zones', 'polski'), 'type' => 'textarea', 'default' => 'Configure <a href="%s">shipping zones</a> for deliveries in Poland.'],
                    ['key' => 'polski_general|admin_next_steps_products', 'label' => __('Step - product data', 'polski'), 'type' => 'textarea', 'default' => 'Complete product data, add unit prices and delivery times in the <a href="%s">Polski tab</a> for each product.'],
                    ['key' => 'polski_general|admin_next_steps_checkout', 'label' => __('Step - checkout test', 'polski'), 'type' => 'textarea', 'default' => 'Test the checkout, add a product to the cart and check the legal checkboxes and button text on the <a href="%s">order page</a>.'],
                    ['key' => 'polski_general|admin_omnibus_plugin_detected_text', 'label' => __('Omnibus plugin detected status', 'polski'), 'type' => 'text', 'default' => 'detected, data synchronized'],
                    ['key' => 'polski_general|admin_omnibus_plugin_missing_text', 'label' => __('Omnibus plugin missing status', 'polski'), 'type' => 'text', 'default' => 'not installed'],
                    ['key' => 'polski_general|admin_omnibus_no_external_text', 'label' => __('Communication without external Omnibus plugin', 'polski'), 'type' => 'textarea', 'default' => 'No external Omnibus plugin is installed. Polski uses the built-in price tracking system.'],
                    ['key' => 'polski_general|admin_omnibus_external_active_text', 'label' => __('Communication after external Omnibus plugin detection', 'polski'), 'type' => 'textarea', 'default' => 'External plugin detected. Polski uses its data instead of the built-in system.'],
                ],
            ],
            [
                'id' => 'email_attachments',
                'name' => __('Legal Email Attachments', 'polski'),
                'description' => __('Attaching legal pages content (terms, privacy policy, right of withdrawal) to order confirmation emails.', 'polski'),
                'group' => __('Consumer Rights', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-email',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_emails|attach_terms', 'label' => __('Attach Terms', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_emails|attach_privacy', 'label' => __('Attach Privacy Policy', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_emails|attach_withdrawal', 'label' => __('Attach Right of Withdrawal', 'polski'), 'type' => 'checkbox', 'default' => true],
                ],
            ],

            // === Product Information ===
            [
                'id' => 'manufacturer',
                'name' => __('Manufacturer and GPSR', 'polski'),
                'description' => __('Manufacturer information, responsible person (GPSR), safety documents, safety instructions.', 'polski'),
                'group' => __('Product Information', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-building',
                'links' => [],
                'settings' => [],
            ],
            [
                'id' => 'food_module',
                'name' => __('Food and Supplements', 'polski'),
                'description' => __('Nutrition facts table, allergens, ingredients, Nutri-Score, alcohol content, country of origin, distributor.', 'polski'),
                'group' => __('Product Information', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-carrot',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_food|show_ingredients', 'label' => __('Show ingredients', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_food|show_allergens', 'label' => __('Show allergens', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_food|show_nutrients', 'label' => __('Show nutrition facts table', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_food|show_nutri_score', 'label' => __('Show Nutri-Score', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_food|show_alcohol', 'label' => __('Show alcohol content', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_food|show_origin', 'label' => __('Show country of origin', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_food|show_distributor', 'label' => __('Show distributor', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_food|show_net_filling', 'label' => __('Show net content', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_food|ingredients_label', 'label' => __('Ingredients label', 'polski'), 'type' => 'text', 'default' => __('Ingredients', 'polski')],
                    ['key' => 'polski_food|allergens_label', 'label' => __('Allergens label', 'polski'), 'type' => 'text', 'default' => __('Allergens', 'polski')],
                    ['key' => 'polski_food|nutrients_caption_prefix', 'label' => __('Nutrition facts table header prefix', 'polski'), 'type' => 'text', 'default' => __('Nutrition facts per', 'polski')],
                    ['key' => 'polski_food|nutrients_reference_unit', 'label' => __('Default reference unit', 'polski'), 'type' => 'text', 'default' => '100 g'],
                    ['key' => 'polski_food|nutrients_column_name', 'label' => __('Nutrient column name', 'polski'), 'type' => 'text', 'default' => __('Nutrient', 'polski')],
                    ['key' => 'polski_food|nutrients_column_value', 'label' => __('Value column name', 'polski'), 'type' => 'text', 'default' => __('Value', 'polski')],
                    ['key' => 'polski_food|nutri_score_label', 'label' => __('Nutri-Score label', 'polski'), 'type' => 'text', 'default' => 'Nutri-Score'],
                    ['key' => 'polski_food|alcohol_label', 'label' => __('Alcohol content label', 'polski'), 'type' => 'text', 'default' => __('Alcohol content', 'polski')],
                    ['key' => 'polski_food|alcohol_suffix', 'label' => __('Alcohol suffix', 'polski'), 'type' => 'text', 'default' => '% vol.'],
                    ['key' => 'polski_food|origin_label', 'label' => __('Country of origin label', 'polski'), 'type' => 'text', 'default' => __('Country of origin', 'polski')],
                    ['key' => 'polski_food|distributor_label', 'label' => __('Distributor label', 'polski'), 'type' => 'text', 'default' => __('Distributor', 'polski')],
                    ['key' => 'polski_food|net_filling_label', 'label' => __('Net content label', 'polski'), 'type' => 'text', 'default' => __('Net content', 'polski')],
                ],
            ],
            [
                'id' => 'power_supply',
                'name' => __('Power Supply Info', 'polski'),
                'description' => __('Energy consumption data for electrical devices (energy labels).', 'polski'),
                'group' => __('Product Information', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-lightbulb',
                'links' => [],
                'settings' => [],
            ],

            // === Customer Account ===
            [
                'id' => 'double_opt_in',
                'name' => __('Double Opt-In (DOI)', 'polski'),
                'description' => __('Email address verification during account registration. Activation link sent by email, login block for unactivated accounts.', 'polski'),
                'group' => __('Customer Account', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-lock',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_doi|cleanup_days', 'label' => __('Delete inactive accounts after (days)', 'polski'), 'type' => 'number', 'default' => 7],
                    ['key' => 'polski_doi|login_blocked_text', 'label' => __('Login block message', 'polski'), 'type' => 'text', 'default' => __('Your account is pending activation! Please check your email and click the activation link.', 'polski')],
                    ['key' => 'polski_doi|invalid_link_text', 'label' => __('Invalid link message', 'polski'), 'type' => 'text', 'default' => __('Invalid activation link.', 'polski')],
                    ['key' => 'polski_doi|activation_success_text', 'label' => __('Activation success message', 'polski'), 'type' => 'text', 'default' => __('Excellent! Your account has been activated. You can now log in.', 'polski')],
                    ['key' => 'polski_doi|email_subject', 'label' => __('Email subject', 'polski'), 'type' => 'text', 'default' => __('Activate your account at {site_title}', 'polski'), 'hint' => __('Variables: {site_title}', 'polski')],
                    ['key' => 'polski_doi|email_heading', 'label' => __('Email heading', 'polski'), 'type' => 'text', 'default' => __('Confirm your email address', 'polski')],
                    ['key' => 'polski_doi|email_greeting', 'label' => __('Email greeting', 'polski'), 'type' => 'text', 'default' => __('Hello {name},', 'polski'), 'hint' => __('Variables: {name}', 'polski')],
                    ['key' => 'polski_doi|email_intro_html', 'label' => __('Email content HTML', 'polski'), 'type' => 'textarea', 'default' => __('Thank you for creating an account. Click the button below to activate your account:', 'polski')],
                    ['key' => 'polski_doi|email_button_text', 'label' => __('Email button text', 'polski'), 'type' => 'text', 'default' => __('Activate account', 'polski')],
                    ['key' => 'polski_doi|email_link_intro', 'label' => __('Fallback link text', 'polski'), 'type' => 'text', 'default' => __('If you prefer, copy and paste this link into your browser:', 'polski')],
                    ['key' => 'polski_doi|email_intro_plain', 'label' => __('Email content plain text', 'polski'), 'type' => 'textarea', 'default' => __('Thank you for creating an account. Visit the link below to activate your account:', 'polski')],
                    ['key' => 'polski_doi|additional_content', 'label' => __('Additional email content', 'polski'), 'type' => 'textarea', 'default' => __('If you did not create an account with us, please ignore this email.', 'polski')],
                ],
            ],

            // === Sales and B2B ===
            [
                'id' => 'ajax_search',
                'name' => __('AJAX Search', 'polski'),
                'description' => __('Fast product suggestions while typing, with SKU support, categories, and a lightweight front-end friendly for web vitals.', 'polski'),
                'group' => __('Sales and B2B', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-search',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_search|min_chars', 'label' => __('Minimum characters', 'polski'), 'type' => 'number', 'default' => 2],
                    ['key' => 'polski_search|limit', 'label' => __('Results limit', 'polski'), 'type' => 'number', 'default' => 6],
                    ['key' => 'polski_search|debounce_ms', 'label' => __('Query debounce (ms)', 'polski'), 'type' => 'number', 'default' => 180],
                    ['key' => 'polski_search|show_submit_button', 'label' => __('Show search button', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_search|show_image', 'label' => __('Show thumbnails', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_search|show_price', 'label' => __('Show prices', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_search|show_sku', 'label' => __('Show SKU', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_search|show_view_all_link', 'label' => __('Show view all results link', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_search|search_sku', 'label' => __('Search by SKU', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_search|search_categories', 'label' => __('Search by categories', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_search|include_out_of_stock', 'label' => __('Include out of stock products', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_search|search_label', 'label' => __('Search field label', 'polski'), 'type' => 'text', 'default' => __('Search products', 'polski')],
                    ['key' => 'polski_search|results_label', 'label' => __('Results label', 'polski'), 'type' => 'text', 'default' => __('Product search results', 'polski')],
                    ['key' => 'polski_search|sku_label', 'label' => __('SKU label', 'polski'), 'type' => 'text', 'default' => 'SKU'],
                    ['key' => 'polski_search|placeholder', 'label' => __('Placeholder', 'polski'), 'type' => 'text', 'default' => __('Search products, SKU codes or categories', 'polski')],
                    ['key' => 'polski_search|submit_button_text', 'label' => __('Button text', 'polski'), 'type' => 'text', 'default' => __('Search', 'polski')],
                    ['key' => 'polski_search|no_results_text', 'label' => __('No results text', 'polski'), 'type' => 'text', 'default' => __('No results found for your query.', 'polski')],
                    ['key' => 'polski_search|view_all_text', 'label' => __('View all results text', 'polski'), 'type' => 'text', 'default' => __('View all results', 'polski')],
                ],
            ],

            // === Merchandising ===
            [
                'id' => 'brands',
                'name' => __('Brands', 'polski'),
                'description' => __('Support for product brands independent of the manufacturer, with views on product pages and listings, and its own taxonomy.', 'polski'),
                'group' => __('Merchandising', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-tag',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_brand|show_on_single', 'label' => __('Show on product page', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_brand|show_on_loop', 'label' => __('Show on product listings', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_brand|label', 'label' => __('Label', 'polski'), 'type' => 'text', 'default' => 'Brand'],
                    ['key' => 'polski_brand|show_label', 'label' => __('Show label', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_brand|separator', 'label' => __('Brand separator', 'polski'), 'type' => 'text', 'default' => ', '],
                    ['key' => 'polski_brand|link_terms', 'label' => __('Link to brand archive', 'polski'), 'type' => 'checkbox', 'default' => true],
                ],
            ],
            [
                'id' => 'ajax_filters',
                'name' => __('AJAX Filters', 'polski'),
                'description' => __('Filtering product listings without page reload, including categories, brands, price, stock status, sale, and attributes.', 'polski'),
                'group' => __('Merchandising', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-filter',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_filters|show_on_shop', 'label' => __('Show on shop archives', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_filters|show_title', 'label' => __('Show form header', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_filters|show_categories', 'label' => __('Category filter', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_filters|show_brands', 'label' => __('Brand filter', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_filters|show_price', 'label' => __('Price filter', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_filters|show_stock', 'label' => __('Availability filter', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_filters|show_sale', 'label' => __('Sale filter', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_filters|show_attributes', 'label' => __('Attribute filters', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_filters|max_attribute_taxonomies', 'label' => __('Max number of attributes', 'polski'), 'type' => 'number', 'default' => 4],
                    ['key' => 'polski_filters|title', 'label' => __('Header', 'polski'), 'type' => 'text', 'default' => 'Product Filters'],
                    ['key' => 'polski_filters|category_label', 'label' => __('Category label', 'polski'), 'type' => 'text', 'default' => 'Category'],
                    ['key' => 'polski_filters|category_all_text', 'label' => __('All categories text', 'polski'), 'type' => 'text', 'default' => 'All'],
                    ['key' => 'polski_filters|brand_label', 'label' => __('Brand label', 'polski'), 'type' => 'text', 'default' => 'Brand'],
                    ['key' => 'polski_filters|brand_all_text', 'label' => __('All brands text', 'polski'), 'type' => 'text', 'default' => 'All'],
                    ['key' => 'polski_filters|min_price_label', 'label' => __('Price from label', 'polski'), 'type' => 'text', 'default' => 'Price from'],
                    ['key' => 'polski_filters|max_price_label', 'label' => __('Price to label', 'polski'), 'type' => 'text', 'default' => 'Price to'],
                    ['key' => 'polski_filters|stock_label', 'label' => __('Availability label', 'polski'), 'type' => 'text', 'default' => 'Availability'],
                    ['key' => 'polski_filters|stock_any_text', 'label' => __('Any availability text', 'polski'), 'type' => 'text', 'default' => 'Any'],
                    ['key' => 'polski_filters|stock_instock_text', 'label' => __('Instock product text', 'polski'), 'type' => 'text', 'default' => 'Available immediately'],
                    ['key' => 'polski_filters|sale_label', 'label' => __('Sale label', 'polski'), 'type' => 'text', 'default' => 'Sales'],
                    ['key' => 'polski_filters|attribute_any_text', 'label' => __('Any attribute value text', 'polski'), 'type' => 'text', 'default' => 'Any'],
                    ['key' => 'polski_filters|show_reset_link', 'label' => __('Show reset link', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_filters|submit_text', 'label' => __('Button text', 'polski'), 'type' => 'text', 'default' => 'Filter'],
                    ['key' => 'polski_filters|reset_text', 'label' => __('Reset text', 'polski'), 'type' => 'text', 'default' => 'Clear filters'],
                ],
            ],
            [
                'id' => 'wishlist',
                'name' => __('Wishlist', 'polski'),
                'description' => __('Saving favorite products for guests and logged-in users, with a list in the customer account and AJAX add/remove.', 'polski'),
                'group' => __('Merchandising', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-heart',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_wishlist|allow_guests', 'label' => __('Allow guests to save favorites', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_wishlist|show_on_single', 'label' => __('Show on product page', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_wishlist|show_on_loop', 'label' => __('Show on listings', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_wishlist|show_in_account', 'label' => __('Show in My Account', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_wishlist|show_title', 'label' => __('Show list title', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_wishlist|show_product_image', 'label' => __('Show product images', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_wishlist|show_product_name', 'label' => __('Show product names', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_wishlist|show_price', 'label' => __('Show price in list', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_wishlist|show_add_to_cart', 'label' => __('Show cart button in list', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_wishlist|show_remove_button', 'label' => __('Show remove button in list', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_wishlist|grid_columns', 'label' => __('Number of columns in list', 'polski'), 'type' => 'number', 'default' => 4],
                    ['key' => 'polski_wishlist|account_label', 'label' => __('Label in My Account', 'polski'), 'type' => 'text', 'default' => 'Favorites'],
                    ['key' => 'polski_wishlist|title', 'label' => __('List title', 'polski'), 'type' => 'text', 'default' => 'Your favorite products'],
                    ['key' => 'polski_wishlist|account_intro_text', 'label' => __('Section description', 'polski'), 'type' => 'textarea', 'default' => ''],
                    ['key' => 'polski_wishlist|button_add_text', 'label' => __('Add text', 'polski'), 'type' => 'text', 'default' => 'Add to favorites'],
                    ['key' => 'polski_wishlist|button_remove_text', 'label' => __('Remove text', 'polski'), 'type' => 'text', 'default' => 'Remove from favorites'],
                    ['key' => 'polski_wishlist|login_required_text', 'label' => __('Login message', 'polski'), 'type' => 'text', 'default' => 'Please log in to use the wishlist.'],
                    ['key' => 'polski_wishlist|product_not_found_text', 'label' => __('Product not found message', 'polski'), 'type' => 'text', 'default' => 'Product not found.'],
                    ['key' => 'polski_wishlist|empty_text', 'label' => __('Empty state', 'polski'), 'type' => 'text', 'default' => 'The favorites list is empty.'],
                ],
            ],
            [
                'id' => 'compare',
                'name' => __('Product Comparison', 'polski'),
                'description' => __('Product comparison tool with features table, highlight differences, guest and customer support, and view in My Account.', 'polski'),
                'group' => __('Merchandising', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-randomize',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_compare|allow_guests', 'label' => __('Allow guests to compare products', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_compare|show_on_single', 'label' => __('Show on product page', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_compare|show_on_loop', 'label' => __('Show on listings', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_compare|show_in_account', 'label' => __('Show in My Account', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_compare|show_product_image', 'label' => __('Show product images', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_compare|show_add_to_cart', 'label' => __('Show cart button', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_compare|show_remove_button', 'label' => __('Show remove button', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_compare|account_label', 'label' => __('Label in My Account', 'polski'), 'type' => 'text', 'default' => 'Comparison'],
                    ['key' => 'polski_compare|title', 'label' => __('Comparison title', 'polski'), 'type' => 'text', 'default' => 'Product Comparison'],
                    ['key' => 'polski_compare|max_items', 'label' => __('Maximum number of products', 'polski'), 'type' => 'number', 'default' => 4],
                    ['key' => 'polski_compare|button_add_text', 'label' => __('Add text', 'polski'), 'type' => 'text', 'default' => 'Add to comparison'],
                    ['key' => 'polski_compare|button_remove_text', 'label' => __('Remove text', 'polski'), 'type' => 'text', 'default' => 'Remove from comparison'],
                    ['key' => 'polski_compare|compare_link_text', 'label' => __('Comparison link text', 'polski'), 'type' => 'text', 'default' => 'Compare products'],
                    ['key' => 'polski_compare|clear_text', 'label' => __('Clear text', 'polski'), 'type' => 'text', 'default' => 'Clear comparison'],
                    ['key' => 'polski_compare|feature_label', 'label' => __('Feature column header', 'polski'), 'type' => 'text', 'default' => 'Feature'],
                    ['key' => 'polski_compare|differences_toggle_text', 'label' => __('Difference filter label', 'polski'), 'type' => 'text', 'default' => 'Show only differences'],
                    ['key' => 'polski_compare|login_required_text', 'label' => __('Login message', 'polski'), 'type' => 'text', 'default' => 'Please log in to use product comparison.'],
                    ['key' => 'polski_compare|product_not_found_text', 'label' => __('Product not found message', 'polski'), 'type' => 'text', 'default' => 'Product not found.'],
                    ['key' => 'polski_compare|limit_notice_text', 'label' => __('Limit message', 'polski'), 'type' => 'text', 'default' => 'You can compare up to {limit} products at once. The oldest entry was replaced automatically.', 'hint' => __('Variable: {limit}', 'polski')],
                    ['key' => 'polski_compare|clear_error_text', 'label' => __('Clear error message', 'polski'), 'type' => 'text', 'default' => 'You cannot clear the comparison.'],
                    ['key' => 'polski_compare|intro_text', 'label' => __('Section description', 'polski'), 'type' => 'textarea', 'default' => ''],
                    ['key' => 'polski_compare|empty_text', 'label' => __('Empty state', 'polski'), 'type' => 'text', 'default' => 'The comparison list is empty.'],
                    ['key' => 'polski_compare|highlight_differences', 'label' => __('Highlight differences', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_compare|show_only_differences', 'label' => __('Show only differences by default', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_compare|price_label', 'label' => __('Price label', 'polski'), 'type' => 'text', 'default' => 'Price'],
                    ['key' => 'polski_compare|unit_price_label', 'label' => __('Unit price label', 'polski'), 'type' => 'text', 'default' => 'Unit price'],
                    ['key' => 'polski_compare|sku_label', 'label' => __('SKU label', 'polski'), 'type' => 'text', 'default' => 'SKU'],
                    ['key' => 'polski_compare|availability_label', 'label' => __('Availability label', 'polski'), 'type' => 'text', 'default' => 'Availability'],
                    ['key' => 'polski_compare|delivery_time_label', 'label' => __('Delivery time label', 'polski'), 'type' => 'text', 'default' => 'Delivery time'],
                    ['key' => 'polski_compare|brand_label', 'label' => __('Brand label', 'polski'), 'type' => 'text', 'default' => 'Brand'],
                    ['key' => 'polski_compare|manufacturer_label', 'label' => __('Manufacturer label', 'polski'), 'type' => 'text', 'default' => 'Manufacturer'],
                    ['key' => 'polski_compare|gtin_label', 'label' => __('GTIN / EAN label', 'polski'), 'type' => 'text', 'default' => 'GTIN / EAN'],
                    ['key' => 'polski_compare|description_label', 'label' => __('Short description label', 'polski'), 'type' => 'text', 'default' => 'Short description'],
                    ['key' => 'polski_compare|show_description', 'label' => __('Show short description', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_compare|show_attributes', 'label' => __('Show product attributes', 'polski'), 'type' => 'checkbox', 'default' => true],
                ],
            ],
            [
                'id' => 'quick_view',
                'name' => __('Quick View', 'polski'),
                'description' => __('Lightweight product modal on listings, with support for variations, prices, gallery, and basic purchase information.', 'polski'),
                'group' => __('Merchandising', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-visibility',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_quick_view|show_on_loop', 'label' => __('Show on listings', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|button_text', 'label' => __('Button text', 'polski'), 'type' => 'text', 'default' => 'Quick View'],
                    ['key' => 'polski_quick_view|modal_title', 'label' => __('Modal label', 'polski'), 'type' => 'text', 'default' => 'Product Quick View'],
                    ['key' => 'polski_quick_view|close_label', 'label' => __('Close label', 'polski'), 'type' => 'text', 'default' => 'Close'],
                    ['key' => 'polski_quick_view|loading_text', 'label' => __('Loading text', 'polski'), 'type' => 'text', 'default' => 'Loading product...'],
                    ['key' => 'polski_quick_view|error_text', 'label' => __('AJAX error text', 'polski'), 'type' => 'text', 'default' => 'Could not load product preview.'],
                    ['key' => 'polski_quick_view|product_not_found_text', 'label' => __('Product not found text', 'polski'), 'type' => 'text', 'default' => 'Product not found.'],
                    ['key' => 'polski_quick_view|sku_label', 'label' => __('SKU label', 'polski'), 'type' => 'text', 'default' => 'SKU'],
                    ['key' => 'polski_quick_view|show_modal_label', 'label' => __('Show modal title in content', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|show_close_button', 'label' => __('Show close button', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|show_title', 'label' => __('Show product name', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|show_image', 'label' => __('Show main image', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|show_gallery', 'label' => __('Show mini gallery', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|show_price', 'label' => __('Show price', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|show_unit_price', 'label' => __('Show unit price', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|show_sku', 'label' => __('Show SKU', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|show_delivery_time', 'label' => __('Show delivery time', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|show_brand', 'label' => __('Show brand', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|show_manufacturer', 'label' => __('Show manufacturer', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|show_short_description', 'label' => __('Show short description', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|show_add_to_cart', 'label' => __('Show purchase form', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|show_view_product_link', 'label' => __('Show full product link', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_quick_view|view_product_text', 'label' => __('Link text to product', 'polski'), 'type' => 'text', 'default' => 'View full product page'],
                    ['key' => 'polski_quick_view|view_product_target', 'label' => __('How to open full page', 'polski'), 'type' => 'select', 'default' => 'same_tab', 'options' => ['same_tab' => __('In the same tab', 'polski'), 'new_tab' => __('In a new tab', 'polski')]],
                    ['key' => 'polski_quick_view|show_backdrop_close', 'label' => __('Close by clicking background', 'polski'), 'type' => 'checkbox', 'default' => true],
                ],
            ],
            [
                'id' => 'badge_management',
                'name' => __('Badge Management', 'polski'),
                'description' => __('Merchandising badges on product pages and listings, with automatic conditions and manual per-product highlights.', 'polski'),
                'group' => __('Merchandising', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-awards',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_badges|show_on_single', 'label' => __('Show on product page', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_badges|show_on_loop', 'label' => __('Show on listings', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_badges|show_manual_badge', 'label' => __('Show manual badge', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_badges|manual_badge_style', 'label' => __('Default manual badge style', 'polski'), 'type' => 'select', 'default' => 'accent', 'options' => ['accent' => 'Accent', 'neutral' => 'Neutral', 'warning' => 'Warning', 'success' => 'Success']],
                    ['key' => 'polski_badges|show_secondary_badge', 'label' => __('Show secondary badge', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_badges|secondary_badge_style', 'label' => __('Secondary badge style', 'polski'), 'type' => 'select', 'default' => 'neutral', 'options' => ['accent' => 'Accent', 'neutral' => 'Neutral', 'warning' => 'Warning', 'success' => 'Success']],
                    ['key' => 'polski_badges|shape', 'label' => __('Badge shape', 'polski'), 'type' => 'select', 'default' => 'pill', 'options' => ['pill' => 'Pill', 'rounded' => 'Rounded']],
                    ['key' => 'polski_badges|uppercase', 'label' => __('Uppercase', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_badges|max_badges_single', 'label' => __('Max badges on product page', 'polski'), 'type' => 'number', 'default' => 4],
                    ['key' => 'polski_badges|max_badges_loop', 'label' => __('Max badges on listings', 'polski'), 'type' => 'number', 'default' => 3],
                    ['key' => 'polski_badges|show_sale_badge', 'label' => __('Sale badge', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_badges|sale_badge_text', 'label' => __('Sale badge text', 'polski'), 'type' => 'text', 'default' => 'Sale'],
                    ['key' => 'polski_badges|show_new_badge', 'label' => __('New badge', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_badges|new_badge_text', 'label' => __('New badge text', 'polski'), 'type' => 'text', 'default' => 'New'],
                    ['key' => 'polski_badges|newness_days', 'label' => __('New for how many days', 'polski'), 'type' => 'number', 'default' => 30],
                    ['key' => 'polski_badges|show_low_stock_badge', 'label' => __('Low stock badge', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_badges|low_stock_badge_text', 'label' => __('Low stock badge text', 'polski'), 'type' => 'text', 'default' => 'Last items'],
                    ['key' => 'polski_badges|low_stock_threshold', 'label' => __('Low stock threshold', 'polski'), 'type' => 'number', 'default' => 3],
                    ['key' => 'polski_badges|show_bestseller_badge', 'label' => __('Bestseller badge', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_badges|bestseller_badge_text', 'label' => __('Bestseller badge text', 'polski'), 'type' => 'text', 'default' => 'Bestseller'],
                    ['key' => 'polski_badges|bestseller_threshold', 'label' => __('Bestseller threshold (sales)', 'polski'), 'type' => 'number', 'default' => 25],
                ],
            ],
            [
                'id' => 'tab_manager',
                'name' => __('Tab Manager', 'polski'),
                'description' => __('Additional product tabs with content per product and global tabs for shipping, returns, and business information.', 'polski'),
                'group' => __('Merchandising', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-index-card',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_tabs|enable_global_shipping_tab', 'label' => __('Global shipping tab', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_tabs|shipping_tab_title', 'label' => __('Shipping tab title', 'polski'), 'type' => 'text', 'default' => 'Shipping & Delivery'],
                    ['key' => 'polski_tabs|shipping_tab_content', 'label' => __('Shipping tab content', 'polski'), 'type' => 'textarea', 'default' => ''],
                    ['key' => 'polski_tabs|shipping_tab_priority', 'label' => __('Shipping tab priority', 'polski'), 'type' => 'number', 'default' => 47],
                    ['key' => 'polski_tabs|enable_global_returns_tab', 'label' => __('Global returns tab', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_tabs|returns_tab_title', 'label' => __('Returns tab title', 'polski'), 'type' => 'text', 'default' => 'Returns & Complaints'],
                    ['key' => 'polski_tabs|returns_tab_content', 'label' => __('Returns tab content', 'polski'), 'type' => 'textarea', 'default' => ''],
                    ['key' => 'polski_tabs|returns_tab_priority', 'label' => __('Returns tab priority', 'polski'), 'type' => 'number', 'default' => 48],
                    ['key' => 'polski_tabs|enable_product_tab_1', 'label' => __('Enable first product tab', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_tabs|product_tab_1_priority', 'label' => __('First product tab priority', 'polski'), 'type' => 'number', 'default' => 45],
                    ['key' => 'polski_tabs|enable_product_tab_2', 'label' => __('Enable second product tab', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_tabs|product_tab_2_priority', 'label' => __('Second product tab priority', 'polski'), 'type' => 'number', 'default' => 46],
                ],
            ],
            [
                'id' => 'featured_video',
                'name' => __('Featured Video', 'polski'),
                'description' => __('Product video on the product page, embedded from YouTube, Vimeo, or as a local MP4 file in the media section.', 'polski'),
                'group' => __('Merchandising', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-video-alt3',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_featured_video|show_on_single', 'label' => __('Show on product page', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_featured_video|position', 'label' => __('Position', 'polski'), 'type' => 'select', 'default' => 'after_gallery', 'options' => ['after_gallery' => __('Below gallery', 'polski'), 'before_summary' => __('Before product summary', 'polski')]],
                    ['key' => 'polski_featured_video|title', 'label' => __('Section header', 'polski'), 'type' => 'text', 'default' => 'Watch the product in action'],
                    ['key' => 'polski_featured_video|intro_text', 'label' => __('Section description', 'polski'), 'type' => 'textarea', 'default' => ''],
                    ['key' => 'polski_featured_video|show_title', 'label' => __('Show section header', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_featured_video|show_intro', 'label' => __('Show section description', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_featured_video|autoplay', 'label' => __('Autoplay for supported embeds', 'polski'), 'type' => 'checkbox', 'default' => false],
                ],
            ],
            [
                'id' => 'gallery_zoom',
                'name' => __('Gallery & Zoom', 'polski'),
                'description' => __('Lightweight image zoom and simple gallery lightbox without external slider libraries.', 'polski'),
                'group' => __('Merchandising', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-format-gallery',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_gallery_zoom|enable_zoom', 'label' => __('Enable zoom on hover', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_gallery_zoom|zoom_scale', 'label' => __('Zoom scale', 'polski'), 'type' => 'number', 'default' => 1.45],
                    ['key' => 'polski_gallery_zoom|enable_lightbox', 'label' => __('Enable lightbox on click', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_gallery_zoom|dialog_label', 'label' => __('Lightbox window label', 'polski'), 'type' => 'text', 'default' => 'Product gallery preview'],
                    ['key' => 'polski_gallery_zoom|close_label', 'label' => __('Close label', 'polski'), 'type' => 'text', 'default' => 'Close gallery preview'],
                    ['key' => 'polski_gallery_zoom|show_backdrop_close', 'label' => __('Close by clicking background', 'polski'), 'type' => 'checkbox', 'default' => true],
                ],
            ],
            [
                'id' => 'product_slider_carousel',
                'name' => __('Product Slider Carousel', 'polski'),
                'description' => __('Lightweight product slider based on scroll-snap, with related, sale, or featured products.', 'polski'),
                'group' => __('Merchandising', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-images-alt2',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_slider|show_on_single', 'label' => __('Show on product page', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_slider|source', 'label' => __('Product source', 'polski'), 'type' => 'select', 'default' => 'related', 'options' => ['related' => __('Related', 'polski'), 'upsell' => __('Upsell', 'polski'), 'sale' => __('Sale', 'polski'), 'featured' => __('Featured', 'polski')]],
                    ['key' => 'polski_slider|title', 'label' => __('Section header', 'polski'), 'type' => 'text', 'default' => 'Recommended products'],
                    ['key' => 'polski_slider|limit', 'label' => __('Number of products', 'polski'), 'type' => 'number', 'default' => 8],
                    ['key' => 'polski_slider|show_title', 'label' => __('Show section header', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_slider|show_intro_text', 'label' => __('Show section description', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_slider|intro_text', 'label' => __('Section description', 'polski'), 'type' => 'textarea', 'default' => ''],
                    ['key' => 'polski_slider|show_image', 'label' => __('Show product images', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_slider|show_price', 'label' => __('Show prices', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_slider|show_name', 'label' => __('Show product name', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_slider|show_add_to_cart', 'label' => __('Show cart button', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_slider|show_view_all_link', 'label' => __('Show "view all" link', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_slider|show_empty_state', 'label' => __('Show empty state without products', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_slider|empty_text', 'label' => __('Empty state text', 'polski'), 'type' => 'text', 'default' => 'No products to display in this section.'],
                    ['key' => 'polski_slider|view_all_text', 'label' => __('"view all" link text', 'polski'), 'type' => 'text', 'default' => 'View all results'],
                    ['key' => 'polski_slider|view_all_target', 'label' => __('How to open "view all" link', 'polski'), 'type' => 'select', 'default' => 'same_tab', 'options' => ['same_tab' => __('In the same tab', 'polski'), 'new_tab' => __('In a new tab', 'polski')]],
                ],
            ],
            [
                'id' => 'waitlist',
                'name' => __('Waitlist', 'polski'),
                'description' => __('Waitlist for out-of-stock products, with email signup and automatic notifications upon restock.', 'polski'),
                'group' => __('Merchandising', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-email-alt',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_waitlist|show_on_single', 'label' => __('Show on product page', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_waitlist|allow_guests', 'label' => __('Allow guests to sign up', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_waitlist|title', 'label' => __('Header', 'polski'), 'type' => 'text', 'default' => 'Notify me when available'],
                    ['key' => 'polski_waitlist|show_title', 'label' => __('Show header', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_waitlist|intro_text', 'label' => __('Description', 'polski'), 'type' => 'textarea', 'default' => 'Leave your email address and we will let you know when the product is back in stock.'],
                    ['key' => 'polski_waitlist|show_intro', 'label' => __('Show description', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_waitlist|email_label', 'label' => __('Email field label', 'polski'), 'type' => 'text', 'default' => 'Email address'],
                    ['key' => 'polski_waitlist|email_placeholder', 'label' => __('Email field placeholder', 'polski'), 'type' => 'text', 'default' => 'Your email address'],
                    ['key' => 'polski_waitlist|button_text', 'label' => __('Button text', 'polski'), 'type' => 'text', 'default' => 'Notify me'],
                    ['key' => 'polski_waitlist|success_text', 'label' => __('Success message', 'polski'), 'type' => 'text', 'default' => 'Thank you. We have added you to the waitlist.'],
                    ['key' => 'polski_waitlist|privacy_label', 'label' => __('Consent text', 'polski'), 'type' => 'text', 'default' => 'I accept email contact regarding the availability of this product.'],
                    ['key' => 'polski_waitlist|product_not_found_text', 'label' => __('Product not found error', 'polski'), 'type' => 'text', 'default' => 'Product not found.'],
                    ['key' => 'polski_waitlist|disabled_text', 'label' => __('Waitlist unavailable error', 'polski'), 'type' => 'text', 'default' => 'Waitlist is unavailable for this product.'],
                    ['key' => 'polski_waitlist|invalid_email_text', 'label' => __('Invalid email error', 'polski'), 'type' => 'text', 'default' => 'Please enter a valid email address.'],
                    ['key' => 'polski_waitlist|privacy_error_text', 'label' => __('Missing consent error', 'polski'), 'type' => 'text', 'default' => 'You must accept the consent for email contact.'],
                    ['key' => 'polski_waitlist|login_required_text', 'label' => __('Login required error', 'polski'), 'type' => 'text', 'default' => 'Log in to sign up for the waitlist.'],
                    ['key' => 'polski_waitlist|notify_subject', 'label' => __('Email subject', 'polski'), 'type' => 'text', 'default' => 'Product back in stock - {product_name}'],
                    ['key' => 'polski_waitlist|notify_intro_text', 'label' => __('Email intro text', 'polski'), 'type' => 'text', 'default' => 'Product {product_name} is back in stock.', 'hint' => 'Zmienne: {product_name}'],
                    ['key' => 'polski_waitlist|notify_outro_text', 'label' => __('Email footer text', 'polski'), 'type' => 'text', 'default' => 'If you no longer wish to receive such messages, simply ignore this email.'],
                ],
            ],
            [
                'id' => 'infinite_scroll',
                'name' => __('Infinite Scrolling', 'polski'),
                'description' => __('Lightweight loading of subsequent products on WooCommerce archives, with button mode or automatic loading.', 'polski'),
                'group' => __('Merchandising', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-update-alt',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_infinite_scroll|mode', 'label' => __('Operation mode', 'polski'), 'type' => 'select', 'default' => 'button', 'options' => ['button' => __('Button', 'polski'), 'auto' => __('Automatic scroll', 'polski')]],
                    ['key' => 'polski_infinite_scroll|button_text', 'label' => __('Button text', 'polski'), 'type' => 'text', 'default' => 'Load more products'],
                    ['key' => 'polski_infinite_scroll|loading_text', 'label' => __('Loading text', 'polski'), 'type' => 'text', 'default' => 'Loading products...'],
                    ['key' => 'polski_infinite_scroll|error_text', 'label' => __('Loading error text', 'polski'), 'type' => 'text', 'default' => 'Could not load more products.'],
                    ['key' => 'polski_infinite_scroll|end_text', 'label' => __('End of list text', 'polski'), 'type' => 'text', 'default' => 'No more products.'],
                    ['key' => 'polski_infinite_scroll|show_status', 'label' => __('Show status messages', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_infinite_scroll|show_button_in_auto_mode', 'label' => __('Show button also in auto mode', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_infinite_scroll|show_on_shop', 'label' => __('Show on shop page', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_infinite_scroll|show_on_taxonomies', 'label' => __('Show on categories and tags', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_infinite_scroll|auto_after_pages', 'label' => __('How many pages to auto-load', 'polski'), 'type' => 'number', 'default' => 0],
                ],
            ],
            [
                'id' => 'popup',
                'name' => __('WooCommerce Popup', 'polski'),
                'description' => __('Lightweight promotional or lead popup with frequency, delay, and display location control.', 'polski'),
                'group' => __('Merchandising', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-megaphone',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_popup|title', 'label' => __('Header', 'polski'), 'type' => 'text', 'default' => 'Have a question about the product or commercial terms?'],
                    ['key' => 'polski_popup|content', 'label' => __('Content', 'polski'), 'type' => 'textarea', 'default' => 'Contact us if you want to get a B2B offer, wholesale discount, or help with product selection.'],
                    ['key' => 'polski_popup|cta_text', 'label' => __('CTA text', 'polski'), 'type' => 'text', 'default' => 'Go to contact'],
                    ['key' => 'polski_popup|show_title', 'label' => __('Show header', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_popup|show_close_button', 'label' => __('Show close button', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_popup|close_label', 'label' => __('Close label', 'polski'), 'type' => 'text', 'default' => 'Close popup'],
                    ['key' => 'polski_popup|dialog_label', 'label' => __('Dialog box label', 'polski'), 'type' => 'text', 'default' => 'Promotional popup'],
                    ['key' => 'polski_popup|cta_url', 'label' => __('CTA URL', 'polski'), 'type' => 'text', 'default' => ''],
                    ['key' => 'polski_popup|fallback_cta_url', 'label' => __('CTA Fallback URL', 'polski'), 'type' => 'select', 'default' => 'account', 'options' => ['account' => __('My account', 'polski'), 'home' => __('Home page', 'polski'), 'shop' => __('Shop', 'polski')]],
                    ['key' => 'polski_popup|show_cta', 'label' => __('Show CTA button', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_popup|cta_target', 'label' => __('How to open CTA', 'polski'), 'type' => 'select', 'default' => 'same_tab', 'options' => ['same_tab' => __('In the same tab', 'polski'), 'new_tab' => __('In a new tab', 'polski')]],
                    ['key' => 'polski_popup|show_backdrop_close', 'label' => __('Close by clicking background', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_popup|show_on_home', 'label' => __('Home page', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_popup|show_on_shop', 'label' => __('Shop and archives', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_popup|show_on_product', 'label' => __('Product page', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_popup|show_on_cart', 'label' => __('Cart', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_popup|show_on_checkout', 'label' => __('Checkout', 'polski'), 'type' => 'checkbox', 'default' => false],
                    ['key' => 'polski_popup|delay_seconds', 'label' => __('Delay in seconds', 'polski'), 'type' => 'number', 'default' => 4],
                    ['key' => 'polski_popup|frequency_days', 'label' => __('Frequency of re-showing (days)', 'polski'), 'type' => 'number', 'default' => 7],
                ],
            ],
            // === New Compliance Modules 2026 ===
            [
                'id' => 'gpsr',
                'name' => 'GPSR - Product safety',
                'description' => 'GPSR product safety tools: manufacturer and importer data, responsible person, product identifiers, safety warnings, instructions, and CSV bulk import or export.',
                'group' => __('Product Information', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-shield-alt',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_gpsr|display_mode', 'label' => 'Display mode', 'type' => 'select', 'default' => 'accordion', 'options' => ['accordion' => 'Accordion', 'section' => 'Section']],
                    ['key' => 'polski_gpsr|section_title', 'label' => 'Section title', 'type' => 'text', 'default' => 'Product safety'],
                ],
            ],
            [
                'id' => 'verified_review',
                'name' => 'Verified purchase badge',
                'description' => 'Badge shown on reviews from customers who actually purchased the product.',
                'group' => __('Product Information', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-star-filled',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_verified_review|badge_text', 'label' => 'Badge text', 'type' => 'text', 'default' => 'Verified purchase'],
                ],
            ],
            [
                'id' => 'green_claims',
                'name' => __('Anti-greenwashing', 'polski'),
                'description' => __('Fields for products: ecological claim basis, certificate link, expiration date. Compliance with anti-greenwashing directive (September 2026).', 'polski'),
                'group' => __('Product information', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-palmtree',
                'links' => [],
                'settings' => [],
            ],
            [
                'id' => 'dsa_toolkit',
                'name' => __('DSA Toolkit', 'polski'),
                'description' => __('Digital Services Act tools: contact point settings, report form for illegal content or products, and an admin reports screen. Shortcode: [polski_dsa_report].', 'polski'),
                'group' => __('Consumer rights', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-megaphone',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_dsa|contact_name', 'label' => __('DSA contact name', 'polski'), 'type' => 'text', 'default' => ''],
                    ['key' => 'polski_dsa|contact_email', 'label' => __('DSA contact email', 'polski'), 'type' => 'email', 'default' => ''],
                    ['key' => 'polski_dsa|contact_phone', 'label' => __('DSA contact phone', 'polski'), 'type' => 'text', 'default' => ''],
                    ['key' => 'polski_dsa|form_title', 'label' => __('Form title', 'polski'), 'type' => 'text', 'default' => 'Report illegal content'],
                    ['key' => 'polski_dsa|success_text', 'label' => __('Success message', 'polski'), 'type' => 'text', 'default' => 'Thank you for your report. We will review it within 7 business days.'],
                ],
            ],
            [
                'id' => 'ksef_ready',
                'name' => __('KSeF readiness', 'polski'),
                'description' => __('Automatic detection of orders that may require KSeF invoicing based on NIP, plus integration hooks and an admin status indicator.', 'polski'),
                'group' => __('Consumer rights', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-media-spreadsheet',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_ksef|auto_detect_nip', 'label' => __('Automatically detect based on NIP', 'polski'), 'type' => 'checkbox', 'default' => true],
                ],
            ],
            [
                'id' => 'security_incidents',
                'name' => __('Security incidents', 'polski'),
                'description' => __('CRA-oriented incident log for vulnerabilities, breaches, third-party failures, and operational follow-up. Includes status tracking and CSV export.', 'polski'),
                'group' => __('Consumer rights', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-shield',
                'links' => [
                    ['label' => __('Incident log', 'polski'), 'url' => admin_url('admin.php?page=polski-security-incidents')],
                ],
                'settings' => [
                    ['key' => 'polski_security|incident_contact_email', 'label' => __('Security contact email', 'polski'), 'type' => 'email', 'default' => 'security@example.com'],
                    ['key' => 'polski_security|default_reporter_name', 'label' => __('Default reporter name', 'polski'), 'type' => 'text', 'default' => 'Store administrator'],
                ],
            ],

            // === SEO and Optimization ===
            [
                'id' => 'schema_org',
                'name' => __('Structured Data (Schema.org)', 'polski'),
                'description' => __('Automatic injection of advanced JSON-LD tags, supporting product indexing by Google with plugin-specific data preservation.', 'polski'),
                'group' => __('SEO & Optimization', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-search',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_seo|schema_enabled', 'label' => __('Enable structured data integration', 'polski'), 'type' => 'checkbox', 'default' => true, 'hint' => __('Main switch for Schema.org JSON-LD modifications.', 'polski')],
                    ['key' => '_schema_header', 'label' => '', 'type' => 'html', 'html' => '<strong style="font-size:13px;margin-top:8px;display:block;">' . __('Data to include', 'polski') . '</strong>'],
                    ['key' => 'polski_seo|schema_brand', 'label' => __('Include Brand', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_seo|schema_manufacturer', 'label' => __('Include Manufacturer', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_seo|schema_gtin', 'label' => __('Include barcodes (GTIN)', 'polski'), 'type' => 'checkbox', 'default' => true],
                    ['key' => 'polski_seo|schema_unit_price', 'label' => __('Include Unit Price', 'polski'), 'type' => 'checkbox', 'default' => true],
                ],
            ],

            // === Integrations ===
            [
                'id' => 'checkout_toolkit_integration',
                'name' => __('Checkout and consent integration', 'polski'),
                'description' => __('Detection of popular checkout field extensions, cookies, and product data to maintain compatibility of settings and messages.', 'polski'),
                'group' => __('Integrations', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-admin-plugins',
                'settings' => [
                    ['key' => '_checkout_toolkit_status', 'type' => 'html', 'html' => $this->getCheckoutToolkitStatus()],
                ],
                'links' => [
                    ['label' => 'Flexible Checkout Fields', 'url' => 'https://wordpress.org/plugins/flexible-checkout-fields/'],
                ],
            ],

            // === Tools ===
            [
                'id' => 'site_audit',
                'name' => __('Store Audit', 'polski'),
                'description' => __('Automatic verification of the most common issues: missing legal pages, pre-selected checkboxes, company data, GDPR, Omnibus.', 'polski'),
                'group' => __('Tools', 'polski'),
                'enabled' => true,
                'icon' => 'dashicons-search',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_general|remove_data_on_uninstall', 'label' => __('Delete plugin data on uninstall', 'polski'), 'type' => 'checkbox', 'default' => false, 'hint' => __('If enabled, uninstall removes plugin tables, settings, and stored logs including deactivation feedback.', 'polski')],
                ],
            ],
            [
                'id' => 'cra_readiness',
                'name' => __('CRA - Cyber Resilience', 'polski'),
                'description' => __('Cyber Resilience Act: security.txt file (RFC 9116), security contact, vulnerability reporting policy.', 'polski'),
                'group' => __('Tools', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-lock',
                'links' => [],
                'settings' => [
                    ['key' => 'polski_cra|security_contact', 'label' => __('Security contact email', 'polski'), 'type' => 'email', 'default' => ''],
                    ['key' => 'polski_cra|security_policy_url', 'label' => __('Security policy URL', 'polski'), 'type' => 'text', 'default' => ''],
                ],
            ],
            [
                'id' => 'dpa_tracker',
                'name' => __('DPA Registry (GDPR)', 'polski'),
                'description' => __('Detection of third-party services processing customers\' personal data. Tracking the status of data processing agreements.', 'polski'),
                'group' => __('Tools', 'polski'),
                'enabled' => false,
                'icon' => 'dashicons-clipboard',
                'links' => [],
                'settings' => [],
            ],
        ];

        // Apply saved states.
        foreach ($modules as &$module) {
            if (isset($saved[$module['id']])) {
                $module['enabled'] = (bool) $saved[$module['id']];
            }
        }

        return $modules;
    }

    /**
     * Render the modules management page.
     */
    public function render(): void
    {
        $modules = $this->getModules();

        // Toggle CSS + JS.
        $this->renderToggleStyles();

        // Group modules.
        $groups = [];
        foreach ($modules as $module) {
            $groups[$module['group']][] = $module;
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('polski_save_modules', '_polski_modules_nonce');
        echo '<input type="hidden" name="action" value="polski_save_modules" />';

        foreach ($groups as $groupName => $groupModules) {
            echo '<div style="margin-top:30px;">';
            echo '<h2 style="display:flex;align-items:center;gap:8px;">';
            echo esc_html($groupName);
            echo '</h2>';

            echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(350px,1fr));gap:12px;">';

            foreach ($groupModules as $module) {
                $this->renderModuleCard($module, false);
            }

            echo '</div></div>';
        }

        echo '<p class="submit" style="margin-top:20px;">';
        printf(
            '<button type="submit" class="button button-primary button-hero">%s</button>',
            esc_html__('Save modules', 'polski'),
        );
        echo '</p>';

        echo '</form>';
    }

    /**
     * Render a single module card with toggle.
     *
     * @param array<string, mixed> $module
     * @param bool                 $locked
     */
    private function renderModuleCard(array $module, bool $locked): void
    {
        $id = $module['id'];
        $enabled = $module['enabled'];
        $fieldName = "polski_module_{$id}";
        $hasSettings = ! empty($module['settings']);

        $classes = 'sp-card' . ($enabled ? ' sp-card--active' : '') . ($locked ? ' sp-card--locked' : '');

        echo '<div class="' . esc_attr($classes) . '">';

        // Header with icon and toggle.
        echo '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px;">';
        echo '<div style="display:flex;align-items:center;gap:8px;">';

        if (! empty($module['icon'])) {
            echo '<span class="dashicons ' . esc_attr($module['icon']) . '" style="color:#666;"></span>';
        }

        echo '<strong>' . esc_html($module['name']) . '</strong>';

        echo '</div>';

        // Toggle switch.
        echo '<label class="sp-toggle' . ($locked ? ' sp-toggle--locked' : '') . '">';
        printf(
            '<input type="checkbox" name="%s" value="1" %s %s>',
            esc_attr($fieldName),
            checked($enabled, true, false),
            $locked ? 'disabled' : '',
        );
        echo '<span class="sp-toggle__track"></span>';
        echo '<span class="sp-toggle__knob"></span>';
        echo '</label>';

        echo '</div>';

        // Description.
        echo '<p style="margin:0;color:#666;font-size:13px;line-height:1.5;">' . esc_html($module['description']) . '</p>';

        // Links.
        if (! empty($module['links'])) {
            echo '<div style="margin-top:8px;">';
            foreach ($module['links'] as $link) {
                printf(
                    '<a href="%s" target="_blank" rel="noopener" style="font-size:12px;margin-right:12px;">%s &rarr;</a>',
                    esc_url($link['url']),
                    esc_html($link['label']),
                );
            }
            echo '</div>';
        }

        // Settings link button.
        if ($hasSettings && $enabled && ! $locked) {
            $settingsUrl = admin_url('admin.php?page=polski-module-' . $id);
            printf(
                '<div style="margin-top:8px;"><a href="%s" class="button button-small">%s</a></div>',
                esc_url($settingsUrl),
                esc_html__('Settings', 'polski'),
            );
        }

        // Settings panel (collapsible).
        if ($hasSettings && ! $locked) {
            $detailsId = 'polski-settings-' . $id;

            echo '<details id="' . esc_attr($detailsId) . '" style="margin-top:12px;border-top:1px solid #eee;padding-top:10px;">';
            echo '<summary style="cursor:pointer;font-size:12px;color:#0073aa;user-select:none;">' . wp_kses_post(__('Configure &darr;', 'polski')) . '</summary>';
            echo '<div style="margin-top:10px;">';

            foreach ($module['settings'] as $field) {
                $this->renderSettingsField($field);
            }

            echo '</div></details>';
        }

        if ($locked) {
            echo '<div style="position:absolute;top:8px;right:8px;">';
            echo '<span style="font-size:11px;color:#7f54b3;">' . esc_html__('Coming Soon', 'polski') . '</span>';
            echo '</div>';
        }

        echo '</div>';
    }

    /**
     * Render a single settings field within a module card.
     *
     * @param array<string, mixed> $field
     */
    public function renderSettingsField(array $field, bool $tableRow = false): void
    {
        $type = $field['type'] ?? 'text';
        $key = $field['key'] ?? '';
        $label = $field['label'] ?? '';
        $hint = $field['hint'] ?? '';

        // HTML type - raw output.
        if ($type === 'html') {
            echo '<div style="margin-bottom:8px;">' . wp_kses_post($field['html'] ?? '') . '</div>';
            return;
        }

        // Parse key format: "option_name|field_key"
        [$optionName, $fieldKey] = explode('|', $key, 2) + ['', ''];

        // Get current value.
        $options = get_option($optionName, []);
        $options = is_array($options) ? $options : [];
        $currentValue = $options[$fieldKey] ?? ($field['default'] ?? '');
        $inputName = "polski_setting[{$optionName}][{$fieldKey}]";

        if ($tableRow) {
            echo '<tr>';
            echo '<th scope="row">' . esc_html($label) . '</th>';
            echo '<td>';
        } else {
            echo '<div style="margin-bottom:10px;">';
        }

        if ($type === 'checkbox') {
            echo '<label style="display:flex;align-items:center;gap:6px;font-size:13px;">';
            printf(
                '<input type="checkbox" name="%s" value="1" %s>',
                esc_attr($inputName),
                checked($currentValue, true, false),
            );
            echo esc_html($label);
            echo '</label>';
        } else {
            if ($label !== '') {
                echo '<label style="display:block;font-size:12px;font-weight:600;margin-bottom:3px;">' . esc_html($label) . '</label>';
            }

            if ($type === 'text') {
                printf(
                    '<input type="text" name="%s" value="%s" class="regular-text" style="width:100%%;font-size:12px;">',
                    esc_attr($inputName),
                    esc_attr((string) $currentValue),
                );
            } elseif ($type === 'email') {
                printf(
                    '<input type="email" name="%s" value="%s" class="regular-text" style="width:100%%;font-size:12px;">',
                    esc_attr($inputName),
                    esc_attr((string) $currentValue),
                );
            } elseif ($type === 'number') {
                printf(
                    '<input type="number" name="%s" value="%s" class="small-text" style="width:80px;">',
                    esc_attr($inputName),
                    esc_attr((string) $currentValue),
                );
            } elseif ($type === 'textarea') {
                printf(
                    '<textarea name="%s" rows="3" style="width:100%%;font-size:12px;">%s</textarea>',
                    esc_attr($inputName),
                    esc_textarea((string) $currentValue),
                );
            } elseif ($type === 'select') {
                echo '<select name="' . esc_attr($inputName) . '" style="font-size:12px;">';
                foreach (($field['options'] ?? []) as $val => $optLabel) {
                    printf(
                        '<option value="%s" %s>%s</option>',
                        esc_attr($val),
                        selected($currentValue, $val, false),
                        esc_html($optLabel),
                    );
                }
                echo '</select>';
            } elseif ($type === 'delivery_time_select') {
                $terms = get_terms(['taxonomy' => 'polski_delivery_time', 'hide_empty' => false]);
                echo '<select name="' . esc_attr($inputName) . '" style="font-size:12px;">';
                echo '<option value="">-- ' . esc_html__('none', 'polski') . ' --</option>';
                if (is_array($terms)) {
                    foreach ($terms as $term) {
                        if ($term instanceof \WP_Term) {
                            printf(
                                '<option value="%s" %s>%s</option>',
                                esc_attr((string) $term->term_id),
                                selected($currentValue, (string) $term->term_id, false),
                                esc_html($term->name),
                            );
                        }
                    }
                }
                echo '</select>';
            }
        }

        if ($hint !== '') {
            echo '<p class="description">' . esc_html($hint) . '</p>';
        }

        if ($tableRow) {
            echo '</td></tr>';
        } else {
            echo '</div>';
        }
    }

    /**
     * Handle module save form submission.
     */
    public function handleSave(): void
    {
        if (! current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'polski'));
        }

        check_admin_referer('polski_save_modules', '_polski_modules_nonce');

        $modules = $this->getModules();
        $saved = [];

        foreach ($modules as $module) {
            $fieldName = 'polski_module_' . $module['id'];
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $saved[$module['id']] = isset($_POST[$fieldName]) ? true : false;
        }

        update_option(self::OPTION, $saved);

        // Save per-module settings.
        // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- individual values sanitized in sanitizeFieldValue()
        $settingsData = isset($_POST['polski_setting']) ? wp_unslash($_POST['polski_setting']) : [];

        if (is_array($settingsData)) {
            foreach ($settingsData as $optionName => $fields) {
                if (! is_array($fields)) {
                    continue;
                }

                $optionName = sanitize_key($optionName);
                $existing = get_option($optionName, []);
                $existing = is_array($existing) ? $existing : [];

                foreach ($fields as $fieldKey => $value) {
                    $fieldKey = sanitize_key($fieldKey);
                    $field = $this->findFieldDefinition($modules, $optionName, $fieldKey);
                    $existing[$fieldKey] = $this->sanitizeFieldValue($value, $field);
                }

                update_option($optionName, $existing);
            }
        }

        // Handle unchecked checkboxes (they don't send POST data).
        foreach ($modules as $module) {
            if (empty($module['settings'])) {
                continue;
            }

            foreach ($module['settings'] as $field) {
                if (($field['type'] ?? '') !== 'checkbox' || ! isset($field['key'])) {
                    continue;
                }

                [$optName, $fKey] = explode('|', $field['key'], 2) + ['', ''];

                if ($optName === '' || $fKey === '') {
                    continue;
                }

                // If checkbox was not in POST, set to false.
                if (! isset($settingsData[$optName][$fKey])) {
                    $opt = get_option($optName, []);
                    $opt = is_array($opt) ? $opt : [];
                    $opt[$fKey] = false;
                    update_option($optName, $opt);
                }
            }
        }

        \Polski\Service\CacheHelper::flush();

        wp_safe_redirect(admin_url('admin.php?page=polski&modules_saved=1'));
        exit;
    }

    /**
     * @return array<string, bool>
     */
    public static function getDefaultModuleStates(): array
    {
        return [
            'unit_price' => true,
            'omnibus' => true,
            'tax_display' => true,
            'delivery_time' => true,
            'shipping_notice' => true,
            'checkout_button' => true,
            'legal_checkboxes' => true,
            'consent_logging' => true,
            'legal_pages' => true,
            'withdrawal' => true,
            'dispute_resolution' => true,
            'email_attachments' => true,
            'manufacturer' => true,
            'food_module' => false,
            'power_supply' => false,
            'double_opt_in' => false,
            'ajax_search' => false,
            'brands' => false,
            'ajax_filters' => false,
            'wishlist' => false,
            'compare' => false,
            'quick_view' => false,
            'badge_management' => false,
            'tab_manager' => false,
            'featured_video' => false,
            'gallery_zoom' => false,
            'product_slider_carousel' => false,
            'waitlist' => false,
            'infinite_scroll' => false,
            'popup' => false,
            'schema_org' => true,
            'checkout_toolkit_integration' => true,
            'gpsr' => true,
            'verified_review' => false,
            'green_claims' => false,
            'dsa_toolkit' => false,
            'ksef_ready' => false,
            'security_incidents' => true,
            'site_audit' => true,
            'cra_readiness' => false,
            'dpa_tracker' => false,
            'nip_lookup' => false,
        ];
    }

    /**
     * Check if a module is enabled.
     */
    public static function isModuleEnabled(string $moduleId): bool
    {
        $saved = get_option(self::OPTION, []);

        if (! is_array($saved) || ! isset($saved[$moduleId])) {
            $defaults = self::getDefaultModuleStates();

            return $defaults[$moduleId] ?? false;
        }

        return (bool) $saved[$moduleId];
    }

    /**
     * Render CSS and JS for toggle switches.
     */
    private function renderToggleStyles(): void
    {
        echo '<style>
            .sp-card{background:#fff;border:1px solid #ccd0d4;padding:16px;position:relative;transition:border-color .2s;}
            .sp-card--active{border-color:#46b450;}
            .sp-card--locked{opacity:.7;}

            .sp-toggle{position:relative;display:inline-block;width:40px;height:22px;flex-shrink:0;}
            .sp-toggle input{opacity:0;width:0;height:0;position:absolute;}
            .sp-toggle__track{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background:#ccc;border-radius:22px;transition:background .2s;}
            .sp-toggle__knob{position:absolute;height:18px;width:18px;left:2px;bottom:2px;background:#fff;border-radius:50%;transition:transform .2s;box-shadow:0 1px 3px rgba(0,0,0,.2);}
            .sp-toggle input:checked ~ .sp-toggle__track{background:#46b450;}
            .sp-toggle input:checked ~ .sp-toggle__knob{transform:translateX(18px);}
            .sp-toggle--locked .sp-toggle__track{cursor:not-allowed;}
        </style>
        <script>
        document.addEventListener("DOMContentLoaded",function(){
            document.querySelectorAll(".sp-toggle input[type=checkbox]").forEach(function(cb){
                cb.addEventListener("change",function(){
                    var card=this.closest(".sp-card");
                    if(card){
                        card.classList.toggle("sp-card--active",this.checked);
                    }
                });
            });
        });
        </script>';
    }

    /**
     * Get HTML showing Omnibus plugin integration status.
     */
    private function getOmnibusIntegrationStatus(): string
    {
        $generalSettings = get_option('polski_general', []);
        $generalSettings = is_array($generalSettings) ? $generalSettings : [];

        if (! function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugins = [
            ['file' => 'wc-price-history/wc-price-history.php', 'name' => __('Compatible Omnibus Extension A', 'polski')],
            ['file' => 'omnibus/omnibus.php', 'name' => __('Compatible Omnibus Extension B', 'polski')],
        ];

        $html = '<div style="font-size:12px;">';

        $anyActive = false;

        foreach ($plugins as $plugin) {
            $active = is_plugin_active($plugin['file']);
            $icon = $active ? '<span style="color:#46b450;">&#10003;</span>' : '<span style="color:#999;">&#8212;</span>';
            $status = $active
                ? (string) ($generalSettings['admin_omnibus_plugin_detected_text'] ?? __('detected, data synchronized', 'polski'))
                : (string) ($generalSettings['admin_omnibus_plugin_missing_text'] ?? __('not installed', 'polski'));

            if ($active) {
                $anyActive = true;
            }

            $html .= sprintf(
                '<div style="margin-bottom:4px;">%s %s - <em>%s</em></div>',
                $icon,
                esc_html($plugin['name']),
                esc_html($status),
            );
        }

        if (! $anyActive) {
            $html .= '<div style="margin-top:6px;color:#666;">' . esc_html((string) ($generalSettings['admin_omnibus_no_external_text'] ?? __('No external Omnibus plugin is installed. Polski uses the built-in price tracking system.', 'polski'))) . '</div>';
        } else {
            $html .= '<div style="margin-top:6px;color:#46b450;">' . esc_html((string) ($generalSettings['admin_omnibus_external_active_text'] ?? __('External plugin detected. Polski uses its data instead of the built-in system.', 'polski'))) . '</div>';
        }

        $html .= '</div>';

        return $html;
    }

    private function getCheckoutToolkitStatus(): string
    {
        $generalSettings = get_option('polski_general', []);
        $generalSettings = is_array($generalSettings) ? $generalSettings : [];

        if (! function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugins = [
            ['file' => 'flexible-checkout-fields/flexible-checkout-fields.php', 'name' => 'Flexible Checkout Fields'],
            ['file' => 'flexible-cookies/flexible-cookies.php', 'name' => 'Flexible Cookies'],
            ['file' => 'gpsr-for-woocommerce/gpsr-for-woocommerce.php', 'name' => 'GPSR for WooCommerce'],
        ];

        $html = '<div style="font-size:12px;">';
        $anyActive = false;

        foreach ($plugins as $plugin) {
            $active = is_plugin_active($plugin['file']);
            $icon = $active ? '<span style="color:#46b450;">&#10003;</span>' : '<span style="color:#999;">&#8212;</span>';

            if ($active) {
                $anyActive = true;
                $statusHtml = '<em>' . esc_html((string) ($generalSettings['admin_integration_detected_text'] ?? __('detected, integration active', 'polski'))) . '</em>';
            } else {
                $installUrl = admin_url('plugin-install.php?s=' . urlencode($plugin['name']) . '&tab=search&type=term');
                $statusHtml = '<a href="' . esc_url($installUrl) . '">' . esc_html__('install', 'polski') . '</a>';
            }

            $html .= sprintf(
                '<div style="margin-bottom:4px;">%s %s - %s</div>',
                $icon,
                esc_html($plugin['name']),
                $statusHtml,
            );
        }

        if (! $anyActive) {
            $html .= '<div style="margin-top:6px;color:#666;">' . esc_html((string) ($generalSettings['admin_checkout_toolkit_no_external_text'] ?? __('No supported checkout and cookies extensions detected. Polski continues to work independently.', 'polski'))) . '</div>';
        } else {
            $html .= '<div style="margin-top:6px;color:#46b450;">' . esc_html((string) ($generalSettings['admin_checkout_toolkit_external_active_text'] ?? __('Supported checkout, cookies, or product data extensions detected. Polski can adjust integration to the active set.', 'polski'))) . '</div>';
        }

        $html .= '</div>';

        return $html;
    }

    /**
     * @param list<array<string, mixed>> $modules
     * @return array<string, mixed>|null
     */
    private function findFieldDefinition(array $modules, string $optionName, string $fieldKey): ?array
    {
        foreach ($modules as $module) {
            if (empty($module['settings']) || ! is_array($module['settings'])) {
                continue;
            }

            foreach ($module['settings'] as $field) {
                if (! is_array($field) || empty($field['key'])) {
                    continue;
                }

                [$candidateOptionName, $candidateFieldKey] = explode('|', (string) $field['key'], 2) + ['', ''];

                if ($candidateOptionName === $optionName && $candidateFieldKey === $fieldKey) {
                    return $field;
                }
            }
        }

        return null;
    }

    /**
     * @param mixed                     $value
     * @param array<string, mixed>|null $field
     * @return mixed
     */
    private function sanitizeFieldValue(mixed $value, ?array $field): mixed
    {
        $type = $field['type'] ?? 'text';

        return match ($type) {
            'checkbox' => (bool) $value,
            'number' => is_numeric($value) ? $value + 0 : 0,
            'textarea' => sanitize_textarea_field((string) $value),
            'email' => sanitize_email((string) $value),
            'select', 'delivery_time_select', 'text' => sanitize_text_field((string) $value),
            default => is_string($value) ? sanitize_text_field($value) : $value,
        };
    }
}
